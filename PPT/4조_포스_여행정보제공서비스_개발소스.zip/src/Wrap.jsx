import React from "react";
import Home from './Homepage/Home';


const Wrap = () => {
    return (
        <>
            <Home />
        </>
    );
}

export default Wrap;

